define(function(){
	require(["jquery"],function(){
		$("#setPhone").on("click",function(){
			$(this).parents(".container").siblings("#pop").fadeIn();
		});
		$(".nextBtn").on("click",function(){
			$(this).parents(".phonepop").hide();
			$(this).parents(".phonepop").next(".phonepop").fadeIn();
		});
		$(".okBtn,.popclose").on("click",function(){
			$(this).parents("#pop").fadeOut();
		});
		var $dataDetail = $("#data-detail");
		$(".tabs li",$dataDetail).on("click",function(){
			var i = $(this);
			i.addClass("active").siblings().removeClass("active");
			$(".detaillistWrap",$dataDetail).animate({"margin-left":-i.index()*100+"%"},500);
		});
	})
});